# -*- coding: utf-8 -*-

# Units per em of the original system fonts
sf_upm = 2048

# Target units per em of Fira Sans
# Tweak this value to change the apparent size of Fira Sans
fs_target_upm = 1000

weights_text = [         131, 172, 180, 189, 195, 215, 248, 291, 305, 320, 333, 354]
weights_disp = [ 49, 78, 132, 174,                217, 249, 292,                355, 410]